# 🌐 STEP 9 — Turn your repo into a LIVE website (FREE)

Your code is on GitHub. Now we make it a real website anyone can visit.

**Cost: ৳0. No card. No trial. Free forever.**

---

## 9.1 — Open your repository

Go to your repo page (click `vizlab` in "Your repositories").

The address looks like:
```
github.com/YOUR-USERNAME/vizlab
```

---

## 9.2 — Click Settings

At the **top of the repo page** there's a row of tabs:

```
< > Code    ⊙ Issues    ⑂ Pull requests    ▶ Actions    ⚙ Settings
                                                          ↑
                                                      CLICK THIS
```

It's the **last one on the right**, with a gear icon.

> ⚠️ Do NOT use the Settings under your profile picture. It must be the repo's Settings tab.

---

## 9.3 — Click "Pages" in the left sidebar

After clicking Settings, a long list appears on the **left side**.

Scroll down that list. You'll see:

```
General
Access
  Collaborators
  Moderation options
Code and automation
  Branches
  Tags
  Rules
  Actions
  Webhooks
  Environments
  Codespaces
  Pages          ← CLICK THIS
```

---

## 9.4 — Change the Source to "GitHub Actions"

You'll see a section called **"Build and deployment"**.

Under it there's a dropdown labelled **Source**. It currently says:

```
Deploy from a branch
```

**Click that dropdown and choose:**

```
GitHub Actions
```

✅ **That's the only change.** There's no Save button — it saves instantly.

---

## 9.5 — Watch it build

1. Go back to the **top tabs** and click **▶ Actions**

2. You'll see a workflow running called **"Build & Deploy"**

| Icon | Meaning |
|---|---|
| 🟡 yellow dot | Building right now — wait |
| ✅ green tick | Done! Your site is live |
| ❌ red X | Something failed — tell me |

3. **Wait 2–3 minutes.** You can refresh the page.

---

## 9.6 — Visit your live website! 🎉

```
https://YOUR-USERNAME.github.io/vizlab/
```

Replace `YOUR-USERNAME` with your GitHub username.

> ⚠️ Don't forget the **`/vizlab/`** at the end, including the last slash.

**Send this link to anyone. It works on any phone, any computer, anywhere in the world.**

---

# 🔁 How to update your website from now on

This is your permanent routine:

```
1. Edit files in VS Code
2. Press Ctrl+S
3. Open GitHub Desktop
4. Type a summary  (e.g. "added new topic")
5. Click "Commit to main"
6. Click "Push origin"
7. Wait 2 minutes → live site updates automatically
```

**That's it forever.** No servers, no payments, no uploads.

---

# 🆘 If something goes wrong

### ❌ Actions tab shows a red X
Click the failed run → screenshot the red text → send it to me.

### ❌ Website shows 404
- Did you set Source to **GitHub Actions**? (Step 9.4)
- Is your repo named exactly **`vizlab`** (lowercase)?
- Did you include the trailing slash: `/vizlab/`

### ❌ Website loads but is blank white
Your repo name doesn't match. It MUST be `vizlab`.
If you named it something else, tell me and I'll adjust the config.

### ❌ No "Pages" option in the sidebar
Your repo is **Private**. Fix it:
Settings → scroll to the bottom → "Danger Zone" → **Change visibility** → **Make public**

---

# 🎯 Progress

```
✅ Step 3   Node + Git installed
✅ Step 4   Project on PC
✅ Step 5   Running locally
✅ Step 6   First edit made
✅ Step 7   GitHub repo created
✅ Step 8   Code uploaded
👉 Step 9   Publish website        ← YOU ARE HERE
⬜ Step 10  Add your own topic
```

---

# 💬 Tell me

- 🎉 **"it's live!"** + paste your link — I'll check it works
- ❌ **"red X"** — screenshot the error
- ❓ **"can't find Pages"** — tell me what you see in the sidebar
