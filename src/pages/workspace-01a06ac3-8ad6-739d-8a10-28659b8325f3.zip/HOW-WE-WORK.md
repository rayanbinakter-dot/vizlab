# 🤝 How We Work Together

## You never write code. I do that.

Your job is to **decide what the website should teach**.
My job is to **write every line of code**.

---

## 🔄 Our loop

```
1. YOU tell me what you want
   "Add a topic about electricity"
   "Make the buttons bigger"
   "The DNA colors are ugly"

2. I write the code and put files in this workspace

3. YOU download the file(s) and drop them into your folder

4. YOU click 3 buttons in GitHub Desktop

5. Website updates automatically in 2 minutes
```

**That's it. You copy files and click buttons. Nothing else.**

---

## 📥 The only 5 things you ever need to do

### ① Download a file I made
Click the file in this workspace → click Download

### ② Put it in the right folder
I will always tell you the exact path, like:
`C:\projects\vizlab\src\pages\Home.jsx`

### ③ Open GitHub Desktop

### ④ Type any words in the "Summary" box
Example: `update` — it doesn't matter what you type

### ⑤ Click two buttons
- **Commit to main**
- **Push origin**

Wait 2 minutes → your live website is updated.

---

## 💬 How to ask me for things

You do **not** need technical words. Just describe it normally.

| ❌ Don't say | ✅ Just say |
|---|---|
| "Refactor the component" | "Make the homepage simpler" |
| "Add a useState hook" | "Add a button that resets it" |
| "Fix the CSS flexbox" | "The layout looks broken on my phone" |

**Bangla is fine too.** Write however is comfortable.

### Good examples:
- "Add Ohm's law for SSC physics"
- "The text is too small on mobile"
- "I want a chapter on photosynthesis"
- "Change the blue color to green"
- "Remove the HSC button, only SSC for now"

---

## 🛠 If something breaks

**Don't panic and don't try to fix code yourself.**

Just do this:
1. Take a screenshot
2. Send it to me
3. I send back a fixed file

That's the whole process. Broken things are normal and always fixable.

---

## 🚫 What you should NOT do

- ❌ Don't edit `.jsx` files by hand (that caused both errors so far)
- ❌ Don't delete folders you don't recognize
- ❌ Don't click anything that says "Start free trial" or asks for a card
- ❌ Don't worry about understanding the code

---

## ✅ What you SHOULD do

- ✅ Tell me what students need to learn
- ✅ Tell me when something looks wrong
- ✅ Ask "can you make X?" — the answer is usually yes
- ✅ Send screenshots freely

---

## 💰 Money check

| Item | Cost |
|---|---|
| Node.js | ৳0 |
| Git / GitHub | ৳0 |
| GitHub Pages hosting | ৳0 forever |
| VS Code | ৳0 |
| My coding help | ৳0 |

**Total: ৳0**

If any page ever asks for a card — you clicked the wrong button. Close it and ask me.

---

## 🎯 Where we are right now

```
✅ Node + Git installed
✅ Project on your PC
✅ Running at localhost:5173
✅ Code uploaded to GitHub
🔧 Website publishing — fixing one setting
⬜ Then: adding your topics (the fun part)
```

**Your build is confirmed healthy — I tested it. The only problem is a GitHub
Pages setting, which we fix in 30 seconds.**
