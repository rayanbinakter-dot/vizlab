# 🚀 START HERE — Steps 3 to 6

You installed Node.js and GitHub Desktop. Here's exactly what to do next.

**Everything below is FREE. No card. No payment. Ever.**

---

# ✅ STEP 3 — Check your installs worked

Open **Command Prompt**:
- Press `Windows key`
- Type `cmd`
- Press `Enter`

A black window opens. Type this and press Enter:

```
node -v
```

**You should see something like:** `v20.11.0`

Now type this and press Enter:

```
npm -v
```

**You should see something like:** `10.2.4`

### ✅ Both showed a number?
Great, move to Step 4.

### ❌ You saw "not recognized as an internal or external command"?
1. **Close** the black window completely
2. **Restart your computer** (this is required after installing Node)
3. Open `cmd` again and retry

Still failing? Tell me and I'll help.

---

# ✅ STEP 4 — Get the project onto your PC

### 4.1 — Download the zip

In this chat workspace, find the file **`vizlab.zip`** and download it to your PC.

### 4.2 — Make a projects folder

Open **File Explorer** and go to your **C: drive**.

Create a new folder called `projects`

You now have: `C:\projects`

### 4.3 — Unzip

- Find `vizlab.zip` in your Downloads folder
- **Right-click** it → **Extract All...**
- In the box, type: `C:\projects`
- Click **Extract**

### 4.4 — Check it's correct

Open `C:\projects\vizlab`

**You must see these files:**
```
📁 public
📁 src
📄 package.json      ← THIS ONE IS IMPORTANT
📄 index.html
📄 vite.config.js
📄 README.md
```

> ⚠️ **If you see another `vizlab` folder inside** (like `C:\projects\vizlab\vizlab`),
> go into the inner one, select everything, cut it, and paste it into `C:\projects\vizlab`.
> The `package.json` must sit directly inside `C:\projects\vizlab`.

---

# ✅ STEP 5 — Run it on your PC

### 5.1 — Open Command Prompt in the right folder

**Easiest way:**
1. Open `C:\projects\vizlab` in File Explorer
2. Click the **address bar** at the top (where the path is shown)
3. Type `cmd` and press **Enter**

A black window opens, already in the right place. It should say:
```
C:\projects\vizlab>
```

### 5.2 — Install the parts

Type this and press Enter:

```
npm install
```

**Now wait.** This takes **2 to 5 minutes**. You'll see text scrolling and a spinner.

> This downloads ~300MB of free code libraries. It only happens once.
> It is normal to see warnings in yellow. Ignore them.

When it's done you'll see your prompt again: `C:\projects\vizlab>`

### 5.3 — Start the website

Type this and press Enter:

```
npm run dev
```

**You should see:**
```
  VITE v8.2.2  ready in 235 ms

  ➜  Local:   http://localhost:5173/
```

### 5.4 — Open it

Open **Chrome** and go to:

```
http://localhost:5173
```

🎉 **Your website is now running on your own computer.**

---

## ⚠️ Important things to know

| Thing | Answer |
|---|---|
| **Can I close the black window?** | ❌ No! Closing it stops the website. Leave it open while working. |
| **How do I stop the server?** | Click the black window, press `Ctrl + C` |
| **How do I start it again tomorrow?** | Open cmd in the folder, type `npm run dev` |
| **Do I need internet?** | Only for `npm install`. After that it runs offline. |
| **Did I pay anything?** | No. Nothing here costs money. |

---

# ✅ STEP 6 — Make your first edit

Let's prove you can change things.

### 6.1 — Open the project in a text editor

Use **Notepad** for now (we'll install VS Code later if you want).

Go to: `C:\projects\vizlab\src\pages\`

**Right-click** `Home.jsx` → **Open with** → **Notepad**

### 6.2 — Find this text

Press `Ctrl + F` in Notepad and search for: `See the concept`

You'll find this line:

```
<h1>See the concept,<br />not just the equation.</h1>
```

### 6.3 — Change it

Change it to your own words, for example:

```
<h1>Learn science<br />by seeing it.</h1>
```

> ⚠️ Only change the words. Do **not** delete `<h1>`, `<br />`, or `</h1>`.

### 6.4 — Save

Press `Ctrl + S`

### 6.5 — Look at your browser

**Don't refresh.** Just look at the Chrome tab with `localhost:5173`.

**The heading changed by itself.** ✨

That's called hot reload. Every time you save a file, the site updates instantly.

---

# 🎯 You are here

```
✅ Step 1  Looked at the preview
✅ Step 2  (skipped - we'll cover it later)
✅ Step 3  Installed Node + Git
✅ Step 4  Project on your PC
✅ Step 5  Running at localhost:5173
✅ Step 6  Made your first edit

⬜ Step 7  Create free GitHub account
⬜ Step 8  Upload your code to GitHub
⬜ Step 9  Publish website free (GitHub Pages)
⬜ Step 10 Add your own new topic
```

---

# 💬 Reply to me with ONE of these

- ✅ **"step 5 done"** — website is running on my PC
- ✅ **"step 6 done"** — I changed the heading and saw it update
- ❌ **"error"** — and paste the red text you saw
- ❓ **"stuck at 4.3"** — or whichever number you're stuck on

**Don't go to Step 7 yet.** Let's confirm this works first.
