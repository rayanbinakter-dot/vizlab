import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Works on GitHub Pages (yourname.github.io/vizlab) AND on localhost.
  // If you name your repo something other than "vizlab", change it here too.
  base: process.env.NODE_ENV === 'production' ? '/vizlab/' : '/',
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: true,       // required for sandbox / tunnel preview hosts
    hmr: { clientPort: 443 },
  },
  preview: { host: '0.0.0.0', port: 4173, allowedHosts: true },
  build: {
    outDir: 'dist',
    chunkSizeWarningLimit: 1200,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules/three')) return 'three';
          if (id.includes('@react-three')) return 'r3f';
          return null;
        },
      },
    },
  },
});
