# 🐙 Steps 7, 8, 9 — GitHub & Publishing Your Website

**Yes, you understood correctly.** The process is:

```
Create repository  →  Connect your folder to it  →  Upload  →  Publish website
     (Step 7)              (Step 8)                            (Step 9)
```

**All free. No card. No trial.**

---

## 🤔 First — what is a "repository"?

A **repository** (or "repo") is just **a folder that lives on GitHub's website**.

Think of it like Google Drive, but built for code:
- Your PC has: `C:\projects\vizlab`
- GitHub will have: an online copy of that same folder
- **"Push"** = upload your changes from PC → GitHub

Why bother?
1. **Backup** — if your PC dies, your work is safe
2. **Free website hosting** — GitHub turns your repo into a live site
3. **History** — you can undo any mistake, even from last month

---

# ✅ STEP 7 — Create a free GitHub account + repository

### 7.1 — Make an account (skip if you have one)

1. Go to **github.com**
2. Click **Sign up**
3. Enter email, password, and pick a username

> 💡 **Your username becomes part of your website address.**
> If you pick `rahim123`, your site will be `rahim123.github.io/vizlab`
> So pick something you're happy to show people.

4. Verify your email (check your inbox)

**No card is ever requested. If a page asks for payment, you clicked the wrong button — go back.**

### 7.2 — Create the repository

1. Log in to github.com
2. Top-right, click the **`+`** icon → **New repository**

Fill the form **exactly** like this:

| Field | What to do |
|---|---|
| **Repository name** | Type `vizlab` — ⚠️ exactly this, all lowercase |
| **Description** | `3D science visualizations for SSC and HSC` (optional) |
| **Public / Private** | Choose **Public** ⚠️ required for free website hosting |
| **Add a README file** | ❌ **LEAVE UNCHECKED** |
| **Add .gitignore** | ❌ **Leave as "None"** |
| **Choose a license** | ❌ **Leave as "None"** |

3. Click the green **Create repository** button

> ⚠️ **The three ❌ items matter.** If you tick them, GitHub puts files in the repo
> and your upload will be rejected with a confusing error. Leave them empty.

### 7.3 — You'll see a mostly-empty page

That's correct! It's an empty folder waiting for your code.

**Keep this browser tab open** — you'll need it in Step 8.

---

# ✅ STEP 8 — Connect your folder and upload

You have **two options**. Pick ONE.

---

## 🟢 OPTION A — GitHub Desktop (EASIEST — recommended for you)

You already installed it. Use this.

### A1. Open GitHub Desktop and sign in
- **File** → **Options** → **Accounts** → **Sign in**
- Log in with the account you just made

### A2. Add your folder
- **File** → **Add local repository**
- Click **Choose...**
- Navigate to `C:\projects\vizlab`
- Click **Select Folder**

> 💬 **If it says "this directory does not appear to be a Git repository"**
> click the blue **"create a repository"** link in that message, then click
> **Create repository** on the next screen. That's normal.

### A3. Make your first commit
At the bottom-left you'll see a box that says "Summary".

- Type: `first upload`
- Click the blue **Commit to main** button

> A "commit" = saving a snapshot of your work with a label.

### A4. Publish it
- At the top, click **Publish repository**
- Repository name: `vizlab`
- ⚠️ **UNCHECK** the box that says **"Keep this code private"**
- Click **Publish repository**

**Wait ~30 seconds.** Then refresh your GitHub tab in the browser.

🎉 **Your code is on GitHub.**

---

## 🔵 OPTION B — Command Prompt (if you prefer typing)

Open cmd in `C:\projects\vizlab` (click address bar, type `cmd`, Enter).

Run these **one line at a time**:

```
git init
```
```
git add .
```
```
git commit -m "first upload"
```
```
git branch -M main
```

Now the connection line — **replace `YOUR-USERNAME` with your real GitHub username**:

```
git remote add origin https://github.com/YOUR-USERNAME/vizlab.git
```

Then upload:

```
git push -u origin main
```

**A browser window will pop up** asking you to log in to GitHub. Do it. Then the upload runs.

> ⚠️ **First time only:** if git asks who you are, run these two lines first
> (use your own name and the email from your GitHub account):
> ```
> git config --global user.name "Your Name"
> git config --global user.email "you@example.com"
> ```

---

# ✅ STEP 9 — Publish your website (FREE, no card)

Your code is on GitHub. Now let's make it a real website anyone can visit.

### 9.1 — Open your repo settings
1. Go to `github.com/YOUR-USERNAME/vizlab`
2. Click the **Settings** tab (top-right of the repo, gear icon)

### 9.2 — Go to Pages
In the **left sidebar**, scroll down and click **Pages**

### 9.3 — Set the source
Under **"Build and deployment"** → **Source**

Change the dropdown from `Deploy from a branch` to:

### **`GitHub Actions`**

That's the only change. There's no Save button — it saves itself.

### 9.4 — Watch it build
1. Click the **Actions** tab at the top of your repo
2. You'll see a job running with a 🟡 yellow dot
3. **Wait 2–3 minutes**
4. It turns into a ✅ green tick

### 9.5 — Visit your live website! 🎉

```
https://YOUR-USERNAME.github.io/vizlab/
```

**That's a real website. Anyone in the world can open it. It costs you nothing, forever.**

---

# 🔁 From now on — your daily routine

Once set up, updating your live site is this simple:

### With GitHub Desktop:
1. Edit files on your PC
2. Open GitHub Desktop → type a summary → **Commit to main**
3. Click **Push origin**
4. Wait 2 minutes → live site updates automatically

### With cmd:
```
git add .
git commit -m "what I changed"
git push
```

**Every push automatically rebuilds and redeploys your website.** You never touch a server.

---

# 🆘 Common errors

| Error message | What it means | Fix |
|---|---|---|
| `remote origin already exists` | You ran the connect line twice | `git remote remove origin` then run it again |
| `failed to push some refs` | GitHub has files your PC doesn't | `git pull origin main --rebase` then `git push` |
| `Authentication failed` | Login problem | Use GitHub Desktop instead — it handles login for you |
| `src refspec main does not match` | You forgot to commit | Run `git commit -m "first upload"` first |
| Website shows **404** | Pages not enabled | Redo Step 9.3 — source must be **GitHub Actions** |
| Website is **blank/white** | Repo name mismatch | Your repo MUST be named `vizlab` (lowercase) |
| Actions tab shows ❌ red X | Build failed | Click it, screenshot the red text, send to me |

---

# 🎯 Progress

```
✅ Step 3   Installed Node + Git
✅ Step 4   Project on your PC
🔄 Step 5   npm install running...
⬜ Step 6   First edit
⬜ Step 7   Create GitHub repo        ← after step 5
⬜ Step 8   Upload code
⬜ Step 9   Publish website FREE
⬜ Step 10  Add your own topic
```

---

# 💬 What to tell me

- ✅ `"step 5 done"` — I see the site at localhost:5173
- ✅ `"step 8 done"` — my code is on GitHub
- 🎉 `"it's live!"` — send me your website link
- ❌ `"error"` — paste the red text and I'll fix it
